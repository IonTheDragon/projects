-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Сен 13 2019 г., 10:15
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `b92312sl_random`
--

-- --------------------------------------------------------

--
-- Структура таблицы `fields_wiki`
--
-- Создание: Сен 13 2019 г., 07:02
-- Последнее обновление: Сен 13 2019 г., 07:14
--

DROP TABLE IF EXISTS `fields_wiki`;
CREATE TABLE `fields_wiki` (
  `id` int(11) NOT NULL,
  `code` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `type` varchar(64) NOT NULL,
  `description` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `fields_wiki`
--

INSERT INTO `fields_wiki` (`id`, `code`, `name`, `type`, `description`) VALUES
(1, 'id', 'id', 'int', 'Id пользователя, используется для выбора данных по нему из БД'),
(2, 'name', 'Имя', 'varchar(128)', 'Имя пользователя'),
(3, 'sname', 'Фамилия', 'varchar(128)', 'Фамилия пользователя'),
(4, 'fname', 'Отчество', 'varchar(128)', 'Отчество пользователя'),
(5, 'email', 'Email', 'varchar(128)', 'Адрес почты'),
(6, 'gender', 'Пол', 'varchar(128)', 'Пол пользователя, выбирается из трех вариантов'),
(7, 'doctype', 'Тип документа', 'varchar(128)', 'Тип документа, выбирается из существующих вариантов или вписывается пользовательский'),
(8, 'docnum', 'Номер документа', 'varchar(128)', 'Номер документа, для предлагаемых типов документа должен представлять ряд цифр'),
(9, 'access_A', 'доступ А', 'int(1)', 'Права доступа к разделу А'),
(10, 'access_B', 'доступ Б', 'int(1)', 'Права доступа к разделу Б'),
(11, 'access_C', 'доступ В', 'int(1)', 'Права доступа к разделу В'),
(12, 'time', 'Время', 'varchar(128)', 'UTC время записи'),
(13, 'ip', 'ip', 'varchar(128)', 'ip пользователя'),
(14, 'browser', 'Браузер', 'varchar(128)', 'Данные о браузере пользователя');

-- --------------------------------------------------------

--
-- Структура таблицы `random_numbers`
--
-- Создание: Сен 10 2019 г., 12:31
-- Последнее обновление: Сен 11 2019 г., 21:09
--

DROP TABLE IF EXISTS `random_numbers`;
CREATE TABLE `random_numbers` (
  `id` int(11) NOT NULL,
  `requestId` int(8) NOT NULL,
  `number` int(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `random_numbers`
--

INSERT INTO `random_numbers` (`id`, `requestId`, `number`) VALUES
(1, 30, 94),
(6, 1882755, 14),
(7, 1397477, 58),
(8, 553437, 31),
(9, 3812605, 52),
(10, 1169153, 1),
(11, 3814741, -70),
(12, 3974823, -77),
(13, 2217670, 35),
(14, 362303, 16),
(15, 5652408, -26),
(16, 9714025, -24),
(17, 6158877, -62),
(18, 1842904, -41),
(19, 2505007, -30),
(20, 8458354, -15),
(21, 6625502, 92),
(22, 9812473, -87),
(23, 644239, -54),
(24, 6024680, -67),
(25, 2238645, -77),
(26, 7947569, -95),
(27, 2021438, -77),
(28, 7699002, -50);

-- --------------------------------------------------------

--
-- Структура таблицы `user_data`
--
-- Создание: Сен 13 2019 г., 06:17
-- Последнее обновление: Сен 13 2019 г., 06:52
--

DROP TABLE IF EXISTS `user_data`;
CREATE TABLE `user_data` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `sname` varchar(128) NOT NULL,
  `fname` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `gender` varchar(128) NOT NULL,
  `doctype` varchar(128) NOT NULL,
  `docnum` varchar(128) NOT NULL,
  `access_A` int(1) NOT NULL,
  `access_B` int(1) NOT NULL,
  `access_C` int(1) NOT NULL,
  `time` varchar(128) NOT NULL,
  `ip` varchar(128) NOT NULL,
  `browser` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `user_data`
--

INSERT INTO `user_data` (`id`, `name`, `sname`, `fname`, `email`, `gender`, `doctype`, `docnum`, `access_A`, `access_B`, `access_C`, `time`, `ip`, `browser`) VALUES
(1, 'Иван', 'Вознюк', 'Вячеславович', 'ivanstonejungle@gmail.com', 'Мужской', 'Паспорт РФ', '228282', 1, 0, 1, '2019-09-12 17:18:36', '109.171.111.54', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'),
(6, 'Иван', 'Корнилов', 'Васильевич', 'korn@corp.fsb', 'Мужской', 'Военный номер', '1234567890', 1, 1, 1, '2019-09-13 05:33:35', '109.171.111.54', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36'),
(15, 'Stan', 'Kornell', 'Little', 'stan@gmail.com', 'Мужской', 'US special doc', '1283425', 0, 0, 1, '2019-09-13 06:52:11', '109.171.111.54', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `fields_wiki`
--
ALTER TABLE `fields_wiki`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `random_numbers`
--
ALTER TABLE `random_numbers`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `fields_wiki`
--
ALTER TABLE `fields_wiki`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `random_numbers`
--
ALTER TABLE `random_numbers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT для таблицы `user_data`
--
ALTER TABLE `user_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
