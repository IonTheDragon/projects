<?php

return [
    'adminEmail' => 'ivanstonejungle@gmail.com',
    'senderEmail' => 'ivanstonejungle@gmail.com',
    'senderName' => 'ivanstonejungle@gmail.com',
];
